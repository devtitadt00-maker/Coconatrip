/**
 * @file Home.tsx
 * @description Landing page promosi Coconatrip Tour & Travel (spesialis trip Raja Ampat: Piaynemo & Pasir Timbul) dengan galeri foto, informasi one day trip, dan opsi paket menginap. Tema visual menggunakan foto laut Raja Ampat sebagai latar dengan aksen warna hijau.
 */

import type { FC, FormEvent } from 'react'
import { Camera, MapPin, SunMedium, Users } from 'lucide-react'

/**
 * @description Komponen utama halaman Home yang merangkai seluruh section promosi trip Raja Ampat.
 */
const HomePage: FC = () => {
  return (
    <div className="relative min-h-screen text-slate-50">
      {/* Background foto laut Raja Ampat (panorama gugusan pulau) */}
      <div className="pointer-events-none fixed inset-0 -z-20 overflow-hidden">
        <img
          src="https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/85143ee0-ebba-4472-85f8-9430a46204a5.png"
          alt="Panorama gugusan pulau hijau di Raja Ampat dengan laut biru toska."
          className="h-full w-full object-cover object-center"
        />
      </div>
      {/* Overlay tipis agar teks tetap terbaca namun foto tetap tampak jelas dan terasa transparan */}
      <div className="fixed inset-0 -z-10 bg-gradient-to-b from-emerald-950/45 via-slate-950/20 to-emerald-950/60 backdrop-blur-[1px]" />

      <SiteHeader />
      <main className="relative mx-auto flex max-w-6xl flex-col gap-20 px-4 pb-16 pt-28 md:pt-32">
        <HeroSection />
        <HighlightsSection />
        <GallerySection />
        <ItinerarySection />
        <PricingSection />
        <FinalCTASection />
      </main>
      <SiteFooter />
    </div>
  )
}

/**
 * @description Header dengan brand dan navigasi sederhana ke setiap section.
 */
const SiteHeader: FC = () => {
  return (
    <header className="fixed inset-x-0 top-0 z-30 border-b border-white/10 bg-slate-950/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:py-4">
        <a href="#hero" className="flex items-center gap-2">
          <img
            src="https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/17c8bfb2-d33f-47a4-ad59-e055068dc2da.png"
            alt="Logo Coconatrip Tour & Travel"
            className="h-11 w-11 rounded-full border border-emerald-300/70 bg-slate-900/90 object-cover shadow-md shadow-emerald-500/60"
          />
          <div className="leading-tight">
            <p className="text-sm font-semibold tracking-wide text-emerald-100">
              Coconatrip Tour & Travel
            </p>
            <p className="text-[11px] text-slate-300">Spesialis Trip Raja Ampat</p>
          </div>
        </a>
        <nav className="hidden items-center gap-6 text-sm font-medium text-slate-100 md:flex">
          <a href="#highlights" className="hover:text-emerald-300">
            Highlights
          </a>
          <a href="#gallery" className="hover:text-emerald-300">
            Galeri
          </a>
          <a href="#itinerary" className="hover:text-emerald-300">
            Itinerary
          </a>
          <a href="#pricing" className="hover:text-emerald-300">
            Paket
          </a>
          <a
            href="#contact"
            className="rounded-full bg-emerald-400 px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-slate-950 shadow-lg shadow-emerald-400/40 hover:bg-emerald-300"
          >
            Booking
          </a>
        </nav>
      </div>
    </header>
  )
}

/**
 * @description Hero section dengan judul utama, deskripsi singkat, dan call-to-action WhatsApp.
 */
const HeroSection: FC = () => {
  return (
    <section id="hero" className="grid gap-10 md:grid-cols-[1.4fr,1fr] md:items-center">
      <div className="space-y-6">
        <p className="inline-flex items-center rounded-full border border-emerald-400/50 bg-slate-900/70 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-emerald-200 shadow-sm shadow-emerald-500/40">
          One Day Trip & Opsi Menginap • Raja Ampat
        </p>
        <h1 className="text-balance font-extrabold text-emerald-50">
          <span className="block text-sm tracking-[0.35em] sm:text-base md:text-lg">
            TOUR AND TRAVEL
          </span>
          <span className="mt-1 block text-3xl tracking-[0.25em] text-yellow-300 sm:text-4xl md:text-5xl">
            COCONATRIP
          </span>
        </h1>
        <p className="max-w-xl text-balance text-sm leading-relaxed text-slate-100 md:text-base">
          Jelajahi surga Piaynemo & Pasir Timbul di Raja Ampat bersama Coconatrip Tour & Travel
          dalam program One Day Trip dari Waisai, dengan opsi paket menginap 2–3 hari (kisaran 3–5
          juta per orang) untuk menikmati Raja Ampat lebih lama.
        </p>
        <div className="flex flex-wrap items-center gap-4">
          <a
            href="https://wa.me/6282198830473?text=Halo%2C%20saya%20ingin%20info%20Coconatrip%20Tour%20%26%20Travel%20untuk%20trip%20Raja%20Ampat%20Piaynemo."
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center rounded-full bg-emerald-400 px-6 py-2.5 text-sm font-semibold text-slate-950 shadow-lg shadow-emerald-400/40 hover:bg-emerald-300"
          >
            Booking via WhatsApp
          </a>
        </div>
        <div className="mt-4 grid gap-3 text-xs text-slate-100 sm:grid-cols-3">
          <HighlightPill title="Durasi Trip" value="One Day Trip (pagi – sore)" />
          <HighlightPill title="Cocok Untuk" value="Keluarga, komunitas, dan group kantor" />
          <HighlightPill title="Opsi Menginap" value="2–3 hari di Raja Ampat (3–5 jt / orang)" />
        </div>
        <p className="text-[11px] text-slate-300">
          *Program standar One Day Trip dari Waisai. Itinerary dan paket menginap bisa disesuaikan
          dengan kebutuhan rombongan.
        </p>
      </div>
      <div className="space-y-4">
        <div className="flex justify-end">
          <div className="rounded-full border border-emerald-300/80 bg-slate-950/90 p-2.5 shadow-lg shadow-emerald-500/70">
            <img
              src="https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/b36e95e0-6dcb-495d-9c86-7092711fc4ec.png"
              alt="Logo Jalan Jalan Raja Ampat Trip JJR4"
              className="h-16 w-16 rounded-full object-cover md:h-20 md:w-20"
            />
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-4 rounded-3xl bg-emerald-500/35 blur-3xl" />
          <div className="relative overflow-hidden rounded-3xl border border-emerald-200/30 bg-slate-900/70 shadow-2xl">
            <img
              src="https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/d8766ec9-c923-43c8-b565-9fc85c4d82c6.jpeg"
              alt="Pantai pasir putih dan laut biru jernih di Raja Ampat dengan wisatawan bermain di air."
              className="h-64 w-full object-cover md:h-80"
            />
            <div className="space-y-1 border-t border-white/10 bg-gradient-to-r from-slate-950/90 via-slate-900/80 to-slate-950/90 px-4 py-3 text-xs text-slate-100">
              <p className="font-semibold">Pasir Timbul, Raja Ampat</p>
              <p className="text-[11px] text-slate-300">
                Momen terbaik menikmati pasir putih yang muncul di tengah laut ketika air surut.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/**
 * @description Props untuk komponen kecil HighlightPill.
 */
interface HighlightPillProps {
  /** Judul singkat highlight. */
  title: string
  /** Nilai atau detail dari highlight. */
  value: string
}

/**
 * @description Komponen kecil untuk menampilkan informasi singkat di hero section.
 */
const HighlightPill: FC<HighlightPillProps> = ({ title, value }) => {
  return (
    <div className="rounded-2xl border border-emerald-200/40 bg-slate-900/80 px-3 py-2">
      <p className="text-[11px] uppercase tracking-[0.18em] text-emerald-200">{title}</p>
      <p className="mt-0.5 text-xs font-semibold text-slate-50">{value}</p>
    </div>
  )
}

/**
 * @description Section keunggulan trip dalam bentuk kartu dengan ikon.
 */
const HighlightsSection: FC = () => {
  const items: Array<{
    icon: JSX.Element
    title: string
    description: string
  }> = [
    {
      icon: <Camera className="h-5 w-5 text-emerald-300" aria-hidden="true" />,
      title: 'Spot Foto Legendaris Piaynemo',
      description:
        'Nikmati view point TOP VIEW OF PIAYNEMO dengan latar gugusan pulau hijau dan laut biru yang menakjubkan.',
    },
    {
      icon: <Users className="h-5 w-5 text-emerald-300" aria-hidden="true" />,
      title: 'Trip Nyaman untuk Rombongan',
      description:
        'Cocok untuk keluarga, komunitas, dan group kantor. Jadwal fleksibel, bisa disesuaikan kebutuhan rombongan.',
    },
    {
      icon: <MapPin className="h-5 w-5 text-lime-300" aria-hidden="true" />,
      title: 'Destinasi Ikonik Raja Ampat',
      description:
        'Kunjungi Piaynemo, Pasir Timbul, dan spot-spot foto terbaik lainnya bersama pemandu lokal.',
    },
    {
      icon: <SunMedium className="h-5 w-5 text-green-300" aria-hidden="true" />,
      title: 'Laut Jernih & Snorkeling Santai',
      description:
        'Berenang di perairan jernih berwarna toska, santai di pantai pasir putih, dan nikmati sunset yang dramatis.',
    },
  ]

  return (
    <section id="highlights" className="space-y-6">
      <SectionTitle
        eyebrow="Why Coconatrip Tour & Travel"
        title="Kenapa harus ikut trip ini?"
        description="Coconatrip Tour & Travel bekerja sama dengan tim lokal di Raja Ampat untuk memberikan pengalaman terbaik, aman, dan tetap menjaga kelestarian alam."
      />
      <div className="grid gap-5 md:grid-cols-2">
        {items.map((item) => (
          <article
            key={item.title}
            className="flex gap-3 rounded-2xl border border-emerald-200/25 bg-slate-950/80 p-4 shadow-sm shadow-emerald-900/60"
          >
            <div className="mt-1 flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900/90">
              {item.icon}
            </div>
            <div>
              <h3 className="text-sm font-semibold text-emerald-50">{item.title}</h3>
              <p className="mt-1 text-xs leading-relaxed text-slate-200">{item.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

/**
 * @description Props untuk judul section yang dapat digunakan ulang.
 */
interface SectionTitleProps {
  /** Teks kecil di atas judul utama. */
  eyebrow: string
  /** Judul utama section. */
  title: string
  /** Deskripsi singkat section. */
  description?: string
}

/**
 * @description Judul section yang dapat digunakan ulang dengan eyebrow dan deskripsi.
 */
const SectionTitle: FC<SectionTitleProps> = ({ eyebrow, title, description }) => {
  return (
    <div className="space-y-2">
      <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-emerald-300">
        {eyebrow}
      </p>
      <h2 className="text-xl font-semibold tracking-tight text-emerald-50 md:text-2xl">{title}</h2>
      {description ? <p className="max-w-2xl text-sm text-slate-100">{description}</p> : null}
    </div>
  )
}

/**
 * @description Galeri foto dari lokasi-lokasi di Trip Raja Ampat.
 */
const GallerySection: FC = () => {
  const photos: Array<{
    src: string
    alt: string
    label: string
  }> = [
    {
      src: 'https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/d8b20aec-f4d0-424c-815b-3771ebf67064.jpeg',
      alt: 'Rombongan peserta trip berfoto bersama di deck kayu dengan papan bertuliskan Top View of Piaynemo.',
      label: 'Top View of Piaynemo',
    },
    {
      src: 'https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/b61a820c-5cff-4c6f-a067-9564b30ab903.JPG',
      alt: 'Seorang wisatawan berdiri di balkon kayu dengan panorama pulau-pulau hijau di Raja Ampat.',
      label: 'Panorama Gugusan Pulau',
    },
    {
      src: 'https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/b20a67e5-e73e-43f7-a5f9-0c3ebbc742ba.jpeg',
      alt: 'Rombongan wisatawan berfoto di gerbang selamat datang Piaynemo yang dikelilingi pepohonan hijau.',
      label: 'Gerbang Piaynemo',
    },
    {
      src: 'https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/d8766ec9-c923-43c8-b565-9fc85c4d82c6.jpeg',
      alt: 'Pantai pasir putih memanjang di tengah laut dengan banyak wisatawan bermain air di Raja Ampat.',
      label: 'Pasir Timbul Raja Ampat',
    },
    {
      src: 'https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/690ae617-4e0e-4299-a3b9-846a7f945547.JPG',
      alt: 'Speedboat berlayar di laut biru jernih dengan daratan terlihat di kejauhan.',
      label: 'Speedboat di Laut Raja Ampat',
    },
    {
      src: 'https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/ff260f77-ef14-43c3-834f-7327c86dfa50.JPG',
      alt: 'Perahu wisata bersandar di pasir putih dengan wisatawan berjalan santai di tepi pantai.',
      label: 'Boat Sandar di Pasir Putih',
    },
    {
      src: 'https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/7b6dc435-8437-4f92-865f-f3cda551c5c5.JPG',
      alt: 'Keluarga menikmati waktu bersama di tepi pantai berpasir putih dengan laut biru toska.',
      label: 'Keluarga di Pantai Raja Ampat',
    },
    {
      src: 'https://pub-cdn.sider.ai/u/U0W8HK2EWKL/web-coder/69eb1f92416fc6401b87e515/resource/11e2439f-0698-4b4b-b6e4-82071651518d.JPG',
      alt: 'Pasangan berjalan di sepanjang pantai putih dengan laut bergradasi biru dan hijau.',
      label: 'Menikmati Pantai & Laut Toska',
    },
  ]

  return (
    <section
      id="gallery"
      className="space-y-6 rounded-3xl border border-emerald-200/30 bg-slate-950/80 p-5 shadow-inner shadow-emerald-900/60 md:p-6"
    >
      <SectionTitle
        eyebrow="Trip Moments"
        title="Galeri Keindahan Raja Ampat"
        description="Semua foto diambil langsung dari perjalanan ke Raja Ampat: Piaynemo, gugusan pulau, dan pasir timbul yang eksotis."
      />
      <div className="grid gap-4 sm:grid-cols-2">
        {photos.map((photo) => (
          <figure
            key={photo.label}
            className="group overflow-hidden rounded-2xl border border-white/10 bg-slate-900/70"
          >
            <img
              src={photo.src}
              alt={photo.alt}
              className="h-48 w-full object-cover transition duration-500 group-hover:scale-105 md:h-56"
            />
            <figcaption className="flex items-center justify-between border-t border-white/10 bg-slate-950/85 px-3 py-2 text-[11px] text-slate-100">
              <span>{photo.label}</span>
              <span className="text-[10px] text-slate-400">Dokumentasi perjalanan</span>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  )
}

/**
 * @description Section yang menjelaskan garis besar itinerary One Day Trip.
 */
const ItinerarySection: FC = () => {
  const segments: Array<{
    part: string
    title: string
    items: string[]
  }> = [
    {
      part: 'Pagi',
      title: 'Berangkat dari Waisai menuju Piaynemo',
      items: [
        'Meeting point di pelabuhan Waisai, bertemu tim lokal.',
        'Briefing singkat, cek perlengkapan, lalu berangkat dengan speedboat.',
        'Perjalanan menikmati pemandangan gugusan pulau Raja Ampat.',
      ],
    },
    {
      part: 'Siang',
      title: 'Explore TOP VIEW OF PIAYNEMO & sekitarnya',
      items: [
        'Tiba di dermaga Piaynemo, naik ke view point utama untuk menikmati panorama.',
        'Foto bersama di spot ikonik TOP VIEW OF PIAYNEMO dan gerbang Piaynemo.',
        'Explore spot sekitarnya (menyesuaikan kondisi cuaca & gelombang).',
      ],
    },
    {
      part: 'Sore',
      title: 'Pasir Timbul & kembali ke Waisai',
      items: [
        'Menuju Pasir Timbul, bebas bermain pasir putih dan berenang di laut jernih.',
        'Snorkeling santai (opsional, menyesuaikan kondisi peserta & cuaca).',
        'Kembali ke Waisai dan trip one day selesai pada sore hari.',
      ],
    },
  ]

  return (
    <section id="itinerary" className="space-y-6">
      <SectionTitle
        eyebrow="Trip Outline"
        title="Garis Besar Itinerary One Day Trip"
        description="Itinerary berikut adalah contoh susunan One Day Trip Piaynemo & Pasir Timbul dari Waisai. Untuk paket menginap 2–3 hari, susunan kegiatan dapat disesuaikan dengan kebutuhan dan cuaca."
      />
      <div className="space-y-4 rounded-3xl border border-emerald-200/30 bg-slate-950/80 p-5 md:p-6">
        {segments.map((segment) => (
          <article
            key={segment.part}
            className="grid gap-3 rounded-2xl border border-emerald-200/20 bg-slate-900/80 p-4 md:grid-cols-[110px,1fr]"
          >
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-emerald-300">
                {segment.part}
              </p>
              <p className="mt-1 text-xs font-semibold text-slate-50">{segment.title}</p>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-200">
              {segment.items.map((item) => (
                <li key={item} className="flex gap-2">
                  <span className="mt-1 h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>
  )
}

/**
 * @description Section informasi paket, fasilitas yang termasuk, dan cara reservasi.
 */
const PricingSection: FC = () => {
  const includeItems: string[] = [
    'Speedboat selama program sesuai itinerary.',
    'Pemandu lokal berpengalaman di Raja Ampat.',
    'Tiket masuk destinasi yang tertera di itinerary.',
    'Air mineral selama perjalanan boat.',
    'Dokumentasi foto basic (menggunakan kamera tim).',
  ]

  const excludeItems: string[] = [
    'Tiket pesawat menuju dan dari Sorong/Waisai.',
    'Pengeluaran pribadi (belanja, laundry, dan lainnya).',
    'Sewa alat snorkeling / diving spesifik.',
    'Asuransi perjalanan (disarankan untuk peserta).',
  ]

  return (
    <section id="pricing" className="space-y-6">
      <SectionTitle
        eyebrow="Trip Package"
        title="Paket Trip & Fasilitas"
        description="Harga utama untuk program One Day Trip dari Waisai. Untuk paket menginap 2–3 hari di Raja Ampat tersedia kisaran 3–5 juta per orang, menyesuaikan jumlah peserta dan pilihan penginapan."
      />
      <div className="grid gap-5 md:grid-cols-[1.1fr,1fr]">
        <div className="space-y-4 rounded-3xl border border-emerald-300/30 bg-slate-950/80 p-5 shadow-lg shadow-emerald-500/25">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-emerald-300">
            Kisaran Harga*
          </p>
          <p className="text-2xl font-semibold text-emerald-300 md:text-3xl">
            One Day Trip: Rp 2.500.000 / orang
          </p>
          <p className="text-sm font-semibold text-emerald-50">
            Paket Menginap 2–3 hari: sekitar Rp 3.000.000 – 5.000.000 / orang
          </p>
          <p className="text-xs text-slate-100">
            *Estimasi harga per orang, bergantung jumlah peserta, musim, dan tipe akomodasi. Silakan
            hubungi kami untuk penawaran resmi dan tanggal keberangkatan yang tersedia.
          </p>
          <div className="mt-3 flex flex-wrap gap-3 text-[11px] text-slate-100">
            <span className="rounded-full bg-slate-900/90 px-3 py-1">One Day Trip dari Waisai</span>
            <span className="rounded-full bg-slate-900/90 px-3 py-1">Opsi Menginap 2–3 Hari</span>
            <span className="rounded-full bg-slate-900/90 px-3 py-1">Bisa Request Tanggal</span>
          </div>
          <a
            href="https://wa.me/6282198830473?text=Halo%2C%20saya%20ingin%20tanya%20harga%20trip%20Raja%20Ampat%20bersama%20Coconatrip%20Tour%20%26%20Travel."
            target="_blank"
            rel="noreferrer"
            className="mt-5 inline-flex items-center justify-center rounded-full bg-emerald-400 px-5 py-2 text-sm font-semibold text-slate-950 shadow-md shadow-emerald-400/50 hover:bg-emerald-300"
          >
            Tanya harga & ketersediaan
          </a>
        </div>
        <div className="space-y-4 rounded-3xl border border-emerald-200/30 bg-slate-950/80 p-5">
          <div>
            <p className="text-xs font-semibold text-emerald-200">Termasuk Paket</p>
            <ul className="mt-2 space-y-1.5 text-xs text-slate-100">
              {includeItems.map((item) => (
                <li key={item} className="flex gap-2">
                  <span className="mt-1 h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="mt-3 text-xs font-semibold text-rose-200">Belum Termasuk</p>
            <ul className="mt-2 space-y-1.5 text-xs text-slate-100">
              {excludeItems.map((item) => (
                <li key={item} className="flex gap-2">
                  <span className="mt-1 h-1.5 w-1.5 rounded-full bg-rose-400" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

/**
 * @description Nilai formulir booking yang akan dikirim ke WhatsApp.
 */
interface BookingFormValues {
  /** Nama calon peserta atau penanggung jawab rombongan. */
  name: string
  /** Nomor WhatsApp yang bisa dihubungi. */
  whatsapp: string
  /** Perkiraan jumlah peserta. */
  participants: string
  /** Tanggal rencana keberangkatan. */
  date: string
  /** Jenis paket trip yang diminati. */
  packageType: 'one-day' | 'stay'
  /** Catatan tambahan dari calon peserta. */
  note: string
}

/**
 * @description Menyusun pesan WhatsApp berdasarkan data formulir booking.
 * @param values Data dari formulir booking.
 * @returns Pesan siap kirim ke WhatsApp.
 */
const composeWhatsAppMessage = (values: BookingFormValues): string => {
  const packageLabel =
    values.packageType === 'stay'
      ? 'Paket Menginap 2–3 Hari'
      : 'One Day Trip Piaynemo & Pasir Timbul'

  return [
    'Halo, saya ingin booking dengan *Coconatrip Tour & Travel* untuk trip Raja Ampat.',
    '',
    `Nama: ${values.name}`,
    `WhatsApp: ${values.whatsapp}`,
    `Jumlah peserta: ${values.participants}`,
    `Rencana tanggal: ${values.date || '- (belum pasti)'}`,
    `Jenis paket: ${packageLabel}`,
    '',
    values.note ? `Catatan tambahan: ${values.note}` : '',
  ]
    .filter(Boolean)
    .join('\n')
}

/**
 * @description Formulir sederhana untuk mengirim permintaan booking via WhatsApp.
 */
const BookingForm: FC = () => {
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()

    const formData = new FormData(event.currentTarget)
    const values: BookingFormValues = {
      name: String(formData.get('name') ?? ''),
      whatsapp: String(formData.get('whatsapp') ?? ''),
      participants: String(formData.get('participants') ?? ''),
      date: String(formData.get('date') ?? ''),
      packageType: (formData.get('packageType') ?? 'one-day') as BookingFormValues['packageType'],
      note: String(formData.get('note') ?? ''),
    }

    const message = composeWhatsAppMessage(values)
    const url = `https://wa.me/6282198830473?text=${encodeURIComponent(message)}`
    window.open(url, '_blank')
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="w-full max-w-md rounded-2xl border border-emerald-200/40 bg-slate-950/85 p-4 text-left shadow-lg shadow-emerald-900/50"
    >
      <p className="text-sm font-semibold text-emerald-50">Formulir Booking Cepat</p>
      <p className="mt-1 text-[11px] text-slate-300">
        Isi data singkat di bawah ini, lalu kami akan hubungi Anda via WhatsApp untuk detail
        itinerary dan harga resmi.
      </p>
      <div className="mt-4 space-y-3 text-xs">
        <div className="space-y-1">
          <label htmlFor="name" className="block font-medium text-slate-100">
            Nama lengkap / PIC rombongan
          </label>
          <input
            id="name"
            name="name"
            required
            className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-slate-50 placeholder-slate-500 outline-none ring-emerald-500/50 focus:border-emerald-400 focus:ring-1"
            placeholder="Contoh: Vendy / Bapak Andi"
          />
        </div>
        <div className="space-y-1">
          <label htmlFor="whatsapp" className="block font-medium text-slate-100">
            Nomor WhatsApp yang aktif
          </label>
          <input
            id="whatsapp"
            name="whatsapp"
            required
            className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-slate-50 placeholder-slate-500 outline-none ring-emerald-500/50 focus:border-emerald-400 focus:ring-1"
            placeholder="Contoh: 082198830473"
          />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <label htmlFor="participants" className="block font-medium text-slate-100">
              Perkiraan jumlah peserta
            </label>
            <input
              id="participants"
              name="participants"
              required
              type="number"
              min={1}
              className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-slate-50 placeholder-slate-500 outline-none ring-emerald-500/50 focus:border-emerald-400 focus:ring-1"
              placeholder="Contoh: 10 orang"
            />
          </div>
          <div className="space-y-1">
            <label htmlFor="date" className="block font-medium text-slate-100">
              Rencana tanggal
            </label>
            <input
              id="date"
              name="date"
              type="date"
              className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-slate-50 placeholder-slate-500 outline-none ring-emerald-500/50 focus:border-emerald-400 focus:ring-1"
            />
          </div>
        </div>
        <div className="space-y-1">
          <label htmlFor="packageType" className="block font-medium text-slate-100">
            Pilihan paket trip
          </label>
          <select
            id="packageType"
            name="packageType"
            className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-slate-50 outline-none ring-emerald-500/50 focus:border-emerald-400 focus:ring-1"
            defaultValue="one-day"
          >
            <option value="one-day">One Day Trip Piaynemo & Pasir Timbul</option>
            <option value="stay">Paket Menginap 2–3 Hari di Raja Ampat</option>
          </select>
        </div>
        <div className="space-y-1">
          <label htmlFor="note" className="block font-medium text-slate-100">
            Catatan tambahan (opsional)
          </label>
          <textarea
            id="note"
            name="note"
            rows={3}
            className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-xs text-slate-50 placeholder-slate-500 outline-none ring-emerald-500/50 focus:border-emerald-400 focus:ring-1"
            placeholder="Contoh: Rombongan keluarga, ada anak kecil, request tanggal akhir Juni."
          />
        </div>
      </div>
      <button
        type="submit"
        className="mt-4 inline-flex w-full items-center justify-center rounded-full bg-emerald-400 px-4 py-2 text-sm font-semibold text-slate-950 shadow-md shadow-emerald-400/50 hover:bg-emerald-300"
      >
        Kirim ke WhatsApp
      </button>
      <p className="mt-2 text-[10px] text-slate-400">
        Dengan mengirim formulir ini, Anda akan dialihkan ke WhatsApp untuk konfirmasi lanjutan.
      </p>
    </form>
  )
}

/**
 * @description Call-to-action akhir, informasi kontak, dan formulir booking cepat.
 */
const FinalCTASection: FC = () => {
  return (
    <section
      id="contact"
      className="space-y-4 rounded-3xl border border-emerald-200/35 bg-gradient-to-r from-emerald-900/85 via-slate-950/90 to-emerald-800/85 p-6 shadow-xl shadow-emerald-900/60 md:p-8"
    >
      <div className="grid gap-6 md:grid-cols-[minmax(0,1.1fr),minmax(0,1fr)] md:items-start">
        <div className="text-left">
          <h2 className="text-xl font-semibold tracking-tight text-emerald-50 md:text-2xl">
            Siap Berangkat ke Raja Ampat?
          </h2>
          <p className="mx-auto max-w-2xl text-sm text-slate-100 md:mx-0">
            Kirim pesan ke WhatsApp kami untuk mendapatkan itinerary lengkap One Day Trip dan paket
            menginap, jadwal keberangkatan, serta penawaran terbaik untuk rombongan Anda.
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-3 text-sm">
            <a
              href="https://wa.me/6282198830473"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center rounded-full bg-emerald-400 px-6 py-2.5 text-sm font-semibold text-slate-950 shadow-lg shadow-emerald-400/45 hover:bg-emerald-300"
            >
              Chat WhatsApp Sekarang
            </a>
            <p className="text-xs text-slate-200">
              Kontak:{' '}
              <span className="font-semibold text-emerald-100">
                Vendy
              </span>{' '}
              • WhatsApp:{' '}
              <span className="font-mono font-semibold text-emerald-200">
                082198830473
              </span>{' '}
              • Email:{' '}
              <span className="font-mono font-semibold text-emerald-200">
                devtitadt00@gmail.com
              </span>
            </p>
          </div>
        </div>
        <BookingForm />
      </div>
    </section>
  )
}

/**
 * @description Footer sederhana dengan informasi hak cipta.
 */
const SiteFooter: FC = () => {
  return (
    <footer className="border-t border-emerald-200/20 bg-slate-950/95 py-4 text-center text-[11px] text-slate-400">
      <p>
        © {new Date().getFullYear()} Coconatrip Tour & Travel • Dokumentasi perjalanan Piaynemo
        & Pasir Timbul.
      </p>
      <p className="mt-1 text-[10px] text-slate-500">
        Background: Pasir Timbul, Raja Ampat.
      </p>
    </footer>
  )
}

export default HomePage
